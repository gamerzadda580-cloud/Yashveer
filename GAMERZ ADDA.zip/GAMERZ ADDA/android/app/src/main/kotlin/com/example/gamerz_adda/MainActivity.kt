package com.example.gamerz_adda

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
